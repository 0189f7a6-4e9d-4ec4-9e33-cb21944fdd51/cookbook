export class Ingredient {
  constructor(
    public quantity: number,
    public name: string,
    public type: string
  ) { }
}
